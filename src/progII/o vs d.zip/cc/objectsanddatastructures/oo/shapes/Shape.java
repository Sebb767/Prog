package cc.objectsanddatastructures.oo.shapes;

public interface Shape
{
  public double calculateArea();
}
