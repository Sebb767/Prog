package cc.objectsanddatastructures.proc.point;

public class Point
{
  public double x;
  public double y;
}
