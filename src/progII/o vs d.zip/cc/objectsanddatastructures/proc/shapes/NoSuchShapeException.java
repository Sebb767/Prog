package cc.objectsanddatastructures.proc.shapes;

public class NoSuchShapeException extends RuntimeException
{
  public NoSuchShapeException(String message)
  {
    super(message);
  }
}
