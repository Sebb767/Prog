package cc.objectsanddatastructures.proc.shapes;

public class Square
{
  public double a;
}
