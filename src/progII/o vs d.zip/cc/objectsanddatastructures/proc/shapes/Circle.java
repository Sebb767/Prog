package cc.objectsanddatastructures.proc.shapes;

public class Circle
{
  public double r;
}
